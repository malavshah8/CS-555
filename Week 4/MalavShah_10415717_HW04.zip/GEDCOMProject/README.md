# CS-555
# AgileMethods
This repository is for coursework in CS555-agile methodologies. We are developing some functionalities for parsing and evaluating GEDCOM file.

Throught the semester we will implement many changes as user stories in the software for evaluating the GEDCOM file. 
